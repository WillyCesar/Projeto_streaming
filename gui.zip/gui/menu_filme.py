from logica import filme


def imprimir_filme(filme):
    codigo  = filme[0]
    titulo = filme[1]
    genero = filme[2]
    ano = filme[3]
    print ("Codigo: ", codigo)
    print ("Titulo: ",  filme[1])
    print ("Genero: ", filme[2])
    print ("Ano: ", filme[3])
    print ()

def menu_adicionar():
    print ("\nAdicionar Filme \n")
    titulo = str (input("Titulo: "))
    genero = str (input("Genero: "))
    ano = int(input("Ano: "))
    filme.adicionar_filme(titulo, genero, ano)

def menu_listar():
    print ("\nListar Filmes \n")
    filmes = filme.listar_filmes()
    for f in filmes:
        imprimir_filme(f)

def menu_buscar():
    print ("\nBuscar Filme por Titulo \n")
    codigo = int(input("Codigo: "))
    f = filme.buscar_filme(codigo)
    if (f == None):
        print ("Filme não encontrado")
    else:
        imprimir_filme(f)
        
def menu_remover():
    print ("\nRemover Filme \n")
    codigo = int(input("Codigo: "))
    f = filme.remover_filme(codigo)
    if (f == False):
        print ("Filme não encontrado")
    else:
        print ("Filme removido")
    

def mostrar_menu():
    run_filme = True
    menu = ("\n----------------\n"+
             "(1) Adicionar novo Filme \n" +
             "(2) Listar Filmes \n" +
             "(3) Buscar Filme por Codigo \n" +
             "(4) Remover Filme por Codigo \n" +
             "(0) Voltar\n"+
            "----------------")
    
    while(run_filme):
        print (menu)
        op = int(input("Digite sua escolha: "))

        if (op == 1):
            menu_adicionar()
        elif(op == 2):
            menu_listar()
        elif(op == 3):       
            menu_buscar()
        elif (op == 4):
            menu_remover()
        elif (op == 0):
            run_filme = False
    
