filmes = []
codigo_geral = 0

def _gerar_codigo():
    global codigo_geral
    codigo_geral += 1
    return codigo_geral

def adicionar_filme(titulo, genero, ano):
    codigo = _gerar_codigo()
    filme = [codigo, titulo, genero, ano]
    filmes.append(filme)
    
def listar_filmes():
    return filmes

def buscar_filme(codigo):
    for f in filmes:
        if (f[0] == codigo):
            return f
    return None
        
def remover_filme(codigo):
    for f in filmes:
        if (f[0] == codigo):
            filmes.remove(f)
            return True
    return False
        
    
def iniciar_filmes():
    adicionar_filme("Velozes & Furiosos", "Ação", "2015")
    adicionar_filme("Invocaçao Do Mal", "Terror", "2016")
