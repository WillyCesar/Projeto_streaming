usuarios = []


def adicionar_usuario(cpf, nome, email, senha):    
    usuario = [cpf, nome, email, senha]
    usuarios.append(usuario)
    
def listar_usuarios():
    return usuarios

def buscar_usuario(cpf):
    for u in usuarios:
        if (u[0] == cpf):
            return u
    return None
        
def remover_usuario(cpf):
    for u in usuarios:
        if (u[0] == cpf):
            usuarios.remove(u)
            return True
    return False
        
    
def iniciar_usuarios():
    adicionar_usuario(45562626829, "Nicholas", "nicholas-ken@hotmail.com", 123321)
    adicionar_usuario(92862626554, "Random", "random.r@hotmail.com", 151515)
